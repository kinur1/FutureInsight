package com.futureInsight;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_Close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                    new DashboardFragment()).commit();
            navigationView.setCheckedItem(R.id.nav_home);
        }
    }

    public void showExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Apakah Anda yakin ingin keluar?")
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Batalkan dialog jika pengguna memilih "Tidak"
                        dialog.dismiss();
                    }
                });

        AlertDialog exitDialog = builder.create();
        exitDialog.show();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        String fragmentTag = "";

        if (item.getItemId() == R.id.nav_home) {
            fragmentTag = "homeFragment";
        } else if (item.getItemId() == R.id.nav_data) {
            fragmentTag = "dataFragment";
        } else if (item.getItemId() == R.id.nav_predict) {
            fragmentTag = "predictFragment";
        } else if (item.getItemId() == R.id.nav_ticker) {
            fragmentTag = "tickerFragment";
        } else if (item.getItemId() == R.id.nav_exit) {
            showExitDialog();
            return true; // Return true agar drawer tidak tertutup setelah menampilkan dialog exit
        }

        if (!fragmentTag.isEmpty()) {
            Fragment selectedFragment = getSupportFragmentManager().findFragmentByTag(fragmentTag);

            if (selectedFragment == null) {
                // Fragment belum ada dalam stack, tambahkan fragment baru
                switch (fragmentTag) {
                    case "homeFragment":
                        selectedFragment = new DashboardFragment();
                        break;
                    case "dataFragment":
                        selectedFragment = new DataFragment();
                        break;
                    case "predictFragment":
                        selectedFragment = new PredictFragment();
                        break;
                    case "tickerFragment":
                        selectedFragment = new TickerFragment();
                        break;
                }

                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment, fragmentTag).commit();
            }
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            // Tampilkan dialog exit saat tombol back ditekan
            showExitDialog();
        }
    }
}