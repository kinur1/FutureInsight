package com.futureInsight;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class DataFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_predict, container, false);

        // Temukan WebView dalam layout Anda
        WebView webView = rootView.findViewById(R.id.PredictView);

        // Aktifkan JavaScript dan DOM Storage jika diperlukan
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true); // Enable DOM storage

        // Set WebViewClient untuk menangani alih arah di dalam WebView
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Load URL di dalam WebView
                view.loadUrl(request.getUrl().toString());
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Tambahkan JavaScript untuk menangani error
                view.evaluateJavascript("window.onerror = function(message, source, lineno, colno, error) {" +
                        "console.log('Error: ' + message + ' at ' + source + ':' + lineno + ':' + colno);" +
                        "};", null);
            }
        });

        // Set WebChromeClient untuk menangani JavaScript alert, console, dll.
        webView.setWebChromeClient(new WebChromeClient());

        // Muat URL ke dalam WebView
        webView.loadUrl("https://datchart.streamlit.app/");

        return rootView;
    }
}
