package com.futureInsight;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CompanyAdapter extends RecyclerView.Adapter<CompanyAdapter.CompanyViewHolder> {

    private List<Company> companyList;

    public CompanyAdapter(List<Company> companyList) {
        this.companyList = companyList;
    }

    @NonNull
    @Override
    public CompanyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_company, parent, false);
        return new CompanyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CompanyViewHolder holder, int position) {
        Company company = companyList.get(position);

        // Set nomor urut otomatis (posisi + 1)
        holder.tvNo.setText(String.valueOf(position + 1));
        holder.tvCode.setText(company.getCode());
        holder.tvName.setText(company.getName());
        holder.tvDate.setText(company.getDate());
        holder.tvShare.setText(company.getShare());
        holder.tvBoard.setText(company.getBoard());
    }

    @Override
    public int getItemCount() {
        return companyList.size();
    }

    // Inner class ViewHolder harus static dan berada di dalam CompanyAdapter
    public static class CompanyViewHolder extends RecyclerView.ViewHolder {
        TextView tvNo, tvCode, tvName, tvDate, tvShare, tvBoard;

        public CompanyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNo = itemView.findViewById(R.id.tvNo);
            tvCode = itemView.findViewById(R.id.tvCode);
            tvName = itemView.findViewById(R.id.tvName);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvShare = itemView.findViewById(R.id.tvShare);
            tvBoard = itemView.findViewById(R.id.tvBoard);
        }
    }
}
