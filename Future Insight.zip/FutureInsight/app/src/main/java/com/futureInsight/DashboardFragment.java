package com.futureInsight;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class DashboardFragment extends Fragment implements View.OnClickListener {

    private WebView webCMC;

    // Bridge untuk menerima tinggi konten dari HTML
    private class JsBridge {
        @android.webkit.JavascriptInterface
        public void setHeight(final int contentHeightPx) {
            if (webCMC == null) return;
            webCMC.post(() -> {
                ViewGroup.LayoutParams lp = webCMC.getLayoutParams();
                // minimal tinggi 150dp, auto-fit sesuai konten
                float density = getResources().getDisplayMetrics().density;
                int minPx = (int) (150 * density);
                lp.height = Math.max(minPx, contentHeightPx);
                webCMC.setLayoutParams(lp);
            });
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // --- WebView CoinMarketCap (responsif) ---
        webCMC = view.findViewById(R.id.webCMC);
        if (webCMC != null) {
            WebSettings s = webCMC.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
            s.setBuiltInZoomControls(false);
            s.setDisplayZoomControls(false);
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW); // aman karena HTTPS

            webCMC.setBackgroundColor(Color.TRANSPARENT);
            webCMC.setWebViewClient(new WebViewClient());
            webCMC.addJavascriptInterface(new JsBridge(), "Android");
            webCMC.loadUrl("file:///android_asset/cmc_widget.html");
        }

        // --- Menu cards / click listeners ---
        View layoutPredict = view.findViewById(R.id.layout_predict);
        View layoutData    = view.findViewById(R.id.layout_data);
        View layoutTicker  = view.findViewById(R.id.layout_ticker);
        View layoutExit    = view.findViewById(R.id.layout_exit);

        layoutPredict.setOnClickListener(this);
        layoutData.setOnClickListener(this);
        layoutTicker.setOnClickListener(this);
        layoutExit.setOnClickListener(this);

        // Disable link click
        webCMC.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return true; // blok semua link
            }
        });

        // Disable semua input touch
        webCMC.setOnTouchListener((v, event) -> true);

        webCMC.loadUrl("file:///android_asset/cmc_widget.html");

    }

    @Override
    public void onClick(View view) {
        FragmentManager fm = getParentFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        if (view.getId() == R.id.layout_predict) {
            ft.replace(R.id.fragment_container, new PredictFragment(), "predictFragment");
        } else if (view.getId() == R.id.layout_data) {
            ft.replace(R.id.fragment_container, new DataFragment(), "dataFragment");
        } else if (view.getId() == R.id.layout_ticker) {
            ft.replace(R.id.fragment_container, new TickerFragment(), "tickerFragment");
        } else if (view.getId() == R.id.layout_exit) {
            showExitDialog();
            return;
        }

        boolean hasDash = false;
        for (int i = 0; i < fm.getBackStackEntryCount(); i++) {
            if ("dashboardFragment".equals(fm.getBackStackEntryAt(i).getName())) { hasDash = true; break; }
        }
        if (!hasDash) ft.addToBackStack("dashboardFragment");

        ft.commit();
    }

    private void showExitDialog() {
        ((MainActivity) requireActivity()).showExitDialog();
    }

    @Override
    public void onDestroyView() {
        if (webCMC != null) {
            webCMC.loadUrl("about:blank");
            webCMC.clearHistory();
            webCMC.destroy();
            webCMC = null;
        }
        super.onDestroyView();
    }
}
