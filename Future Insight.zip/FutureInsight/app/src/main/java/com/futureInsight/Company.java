package com.futureInsight;

public class Company {
    private String no;
    private String code;
    private String name;
    private String date;
    private String share;
    private String board;

    public Company(String no, String code, String name, String date, String share, String board) {
        this.no = no;
        this.code = code;
        this.name = name;
        this.date = date;
        this.share = share;
        this.board = board;
    }

    public String getNo() {
        return no;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getShare() {
        return share;
    }

    public String getBoard() {
        return board;
    }
}
